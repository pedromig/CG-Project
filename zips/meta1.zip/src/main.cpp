#include "cgproject.h"

// Camera Settings
GLfloat camera_radius = 25.0f;
GLfloat camera_angle = M_PI_4;
GLdouble camera[] = {camera_radius * cos(camera_angle),
                     10.0f,
                     camera_radius *sin(camera_angle)};

#define CAMERA_FOV_Y (GLfloat)95
#define CAMERA_FOV_X (GLfloat)(CANVAS_WIDTH / CANVAS_HEIGHT)

void update_camera() {
    if (camera[1] > WORLD_XYZ_FAR) camera[1] = WORLD_XYZ_FAR;
    if (camera[1] < -WORLD_XYZ_FAR) camera[1] = -WORLD_XYZ_FAR;

    camera[0] = camera_radius * cos(camera_angle);
    camera[2] = camera_radius * sin(camera_angle);
}

GLuint texture[6];

void ascii_keyboard_callback(unsigned char key, int x, int y) {

    switch (toupper(key)) {

        // Open Door
        case '1': {
            //if (door_angle < 90)
            door_angle += ROTATE_SPEED;
            break;
        }

        // Close Door
        case '2': {
            //if (door_angle > 0)
            door_angle -= ROTATE_SPEED;
            break;
        }

        // Open Cat Door
        case '3': {
            if (cat_door_angle < 90)
                cat_door_angle += ROTATE_SPEED;
            break;
        }

        // Close Cat Door
        case '4': {
            if (cat_door_angle > -90)
                cat_door_angle -= ROTATE_SPEED;
            break;
        }

        // Open Door Latch
        case '5': {
            if (handle_angle < 20) {
                handle_angle += ROTATE_SPEED;
                latch_dx += 0.007;
            }
            break;
        }

        // Close Door Latch
        case '6': {
            if (handle_angle > 0) {
                handle_angle -= ROTATE_SPEED;
                latch_dx -= 0.007;
            }
            break;
        }

        // Zoom In
        case 'Z': {
            if (camera_radius > WORLD_XYZ_NEAR) {
                camera_radius -= ZOOM_SPEED;
                update_camera();
            }
            break;
        }

        // Zoom Out
        case 'X':
            camera_radius += ZOOM_SPEED;
            update_camera();
            break;

        // More Light Bulb Red Component
        case 'Q': {
            light_bulb_r += 0.5f;
            break;
        }

        // Less Light Bulb Red Component
        case 'A': {
            light_bulb_r -= 0.5f;
            break;
        }

        // More Light Bulb Green Component
        case 'W': {
            light_bulb_g += 0.5f;
            break;
        }

        // Less Light Bulb Green Component
        case 'S': {
            light_bulb_g -= 0.5f;
            break;
        }

        // More Light Bulb Blue Component
        case 'E': {
            light_bulb_b += 0.5f;
            break;
        }

        // Less Light Bulb Blue Component
        case 'D': {
            light_bulb_b -= 0.5f;
            break;
        }

        // More Light Bulb Intesity
        case 'R': {
            light_bulb_intensity += 0.1f;
            break;
        }

        // Less Light Bulb Intesity
        case 'F': {
            light_bulb_intensity -= 0.1f;
            break;
        }

        // Light Bulb ON/OFF
        case 'B': {
            light_bulb_on = !light_bulb_on;
            break;
        }

        // Spotlight ON/OFF
        case 'N': {
            spotlight_on = !spotlight_on;
            break;
        }

        case ESC_KEY:
            exit(EXIT_SUCCESS);
            break;
    }
    glutPostRedisplay();
}

void non_ascii_keyboard_callback(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_UP:
            camera[1] += CAMERA_SPEED;
            break;
        case GLUT_KEY_DOWN:
            camera[1] -= CAMERA_SPEED;
            break;
        case GLUT_KEY_LEFT:
            camera_angle += ANGLE_SPEED;
            break;
        case GLUT_KEY_RIGHT:
            camera_angle -= ANGLE_SPEED;
            break;
    }
    update_camera();
    glutPostRedisplay();
}

void draw_callback(void) {

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glViewport(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(CAMERA_FOV_Y, CAMERA_FOV_X, WORLD_XYZ_NEAR, WORLD_XYZ_FAR);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(camera[0], camera[1], camera[2], 0, 10, 0, 0, 1, 0);

    debug_axis();
    door(0.0, 0.0, 0.0, 0.0);
    glutSwapBuffers();
}

int main(int argc, char *argv[]) {

    // Window Settings
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(CANVAS_WIDTH, CANVAS_HEIGHT);
    glutInitWindowPosition(400, 100);
    glutCreateWindow("CG-Project - Door");

    glClearColor(BLACK);
    glShadeModel(GL_SMOOTH);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_NORMALIZE);
    glEnable(GL_LIGHTING);
    glEnable(GL_BLEND);

    // Lighting Setup
    setup_lights();

    // Texture LoadingITION
    load_texture(&texture[0], "../resources/cat_door.bmp");
    load_texture(&texture[1], "../resources/wood.bmp");
    load_texture(&texture[2], "../resources/glass.bmp");
    load_texture(&texture[3], "../resources/metal.bmp");
    load_texture(&texture[4], "../resources/effect.bmp");
    load_texture(&texture[5], "../resources/metal.bmp");

    // Window Callbacks
    glutDisplayFunc(draw_callback);
    glutSpecialFunc(non_ascii_keyboard_callback);
    glutKeyboardFunc(ascii_keyboard_callback);

    glutMainLoop();

    return EXIT_SUCCESS;
}
