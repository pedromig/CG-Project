#include "cgproject.h"

GLfloat door_angle = 0;
GLfloat cat_door_angle = 0;
GLfloat handle_angle = 0;
GLfloat latch_dx = 0;

void draw_door_handle() {
    glPushMatrix();
    {
        glTranslatef(0, 0, 0.3);
        glScalef(0.2, 0.2, 0.8);
        draw_cylinder(1, 1);
    }
    glPopMatrix();

    glPushMatrix();
    {
        glTranslatef(-0.30, 0, 0.7);
        glRotatef(-90, 0, 1, 0);
        glScalef(0.2, 0.2, 1);
        draw_cylinder(1, 1);
    }
    glPopMatrix();
}

void door(GLfloat x, GLfloat y, GLfloat z, GLfloat angle) {

    update_light(GL_LIGHT0);
    update_light(GL_LIGHT1);

    glPushMatrix();
    {
        glTranslatef(x, y, z);
        glRotatef(angle + door_angle, 0, 1, 0);
        glTranslatef(4, 0.5, z);

        // Door Base
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, texture[1]);
        glPushMatrix();
        {
            glScalef(8, 1, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Cat Door Left
        glPushMatrix();
        {
            glTranslatef(-2.5, 2, 0);
            glScalef(3, 3, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Cat Door Right
        glPushMatrix();
        {
            glTranslatef(2.5, 2, 0);
            glScalef(3, 3, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Cat Door
        glBindTexture(GL_TEXTURE_2D, texture[0]);
        glPushMatrix();
        {
            GLfloat shift_rotation_center = cat_door_angle > 0 ? 0.15f : -0.15f;

            glTranslatef(0, 3.5, -shift_rotation_center);
            glRotatef(cat_door_angle, 1.0f, 0.0f, 0.0f);
            glTranslatef(0, -1.5, shift_rotation_center);
            glScalef(2, 3, 0.3);
            select_material(PLASTIC);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Cat Door texture separator
        glBindTexture(GL_TEXTURE_2D, texture[1]);
        glPushMatrix();
        {
            glTranslatef(0, 4, 0);
            glScalef(8, 1, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Texture Section Left
        glPushMatrix();
        {
            glTranslatef(-3.25, 6.5, 0);
            glScalef(1.5, 4, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Texture Rectangle 1 - // TODO: Find a good texture to place here
        glPushMatrix();
        {
            glTranslatef(-1.5, 6.5, 0);
            glScalef(2, 4, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Texture Section Middle
        glPushMatrix();
        {
            glTranslatef(0, 6.5, 0);
            glScalef(1, 4, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Texture Rectangle 2 // TODO: Find a good texture to place here

        glPushMatrix();
        {
            glTranslatef(1.5, 6.5, 0);
            glScalef(2, 4, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Texture Section Right
        glPushMatrix();
        {
            glTranslatef(3.25, 6.5, 0);
            glScalef(1.5, 4, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Door Handle Section
        glPushMatrix();
        {
            glTranslatef(0, 9.5, 0);
            glScalef(8, 2, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Handle Location
        glDisable(GL_TEXTURE_2D);
        glPushMatrix();
        {
            glTranslatef(3, 9.5, 0);
            glScalef(0.35, 0.3, 0.5);
            select_material(CHROME);
            glutSolidTorus(0.6, 1, 20, 30);
        }
        glPopMatrix();

        // Door Latch
        glPushMatrix();
        {
            glTranslatef(4 - latch_dx, 9.5, 0);
            glScalef(0.3, 0.3, 0.05);
            select_material(CHROME);
            draw_cube(1, true);
        }
        glPopMatrix();

        // Door Handle
        glPushMatrix();
        {
            glTranslatef(3, 9.5, 0);
            glRotatef(handle_angle, 0, 0, 1);
            draw_door_handle();
            glScalef(1, 1, -1);
            select_material(CHROME);
            draw_door_handle();
        }
        glPopMatrix();
        glEnable(GL_TEXTURE_2D);

        // Glass section
        for (int i = 0; i < 3; ++i) {

            glBlendFunc(GL_ONE, GL_ZERO);
            glBindTexture(GL_TEXTURE_2D, texture[1]);
            glPushMatrix();
            {
                glTranslatef(-3.1, 11.5 + 2.5 * i, 0);
                glScalef(1.8, 2, 0.3);
                select_material(DEFAULT);
                draw_cube(1, true);
            }
            glPopMatrix();

            glBlendFunc(GL_ONE, GL_ZERO);
            glPushMatrix();
            {
                glTranslatef(3.1, 11.5 + 2.5 * i, 0);
                glScalef(1.8, 2, 0.3);
                select_material(DEFAULT);
                draw_cube(1, true);
            }
            glPopMatrix();

            // Left Window
            glDisable(GL_TEXTURE_2D);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glPushMatrix();
            {
                glTranslatef(-1.2, 11.5 + 2.5 * i, 0);
                glScalef(2, 2, 0.3);
                select_material(CHROME);
                draw_cube(1, true);
            }
            glPopMatrix();
            glBlendFunc(GL_ONE, GL_ZERO);

            // Window Separator
            glEnable(GL_TEXTURE_2D);
            glBlendFunc(GL_ONE, GL_ZERO);
            glBindTexture(GL_TEXTURE_2D, texture[1]);
            glPushMatrix();
            {
                glTranslatef(0, 11.5 + 2.5 * i, 0);
                glScalef(0.4, 2, 0.3);
                select_material(DEFAULT);
                draw_cube(1, true);
            }
            glPopMatrix();
            glDisable(GL_TEXTURE_2D);

            // Right Window
            glColor4f(1, 1, 1, 0.5);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glPushMatrix();
            {
                glTranslatef(1.2, 11.5 + 2.5 * i, 0);
                glScalef(2, 2, 0.3);
                select_material(CHROME);
                draw_cube(1, true);
            }
            glPopMatrix();

            // Top
            glEnable(GL_TEXTURE_2D);
            glBlendFunc(GL_ONE, GL_ZERO);
            glBindTexture(GL_TEXTURE_2D, texture[1]);
            glPushMatrix();
            {
                glTranslatef(0, 12.75 + 2.5 * i, 0);
                glScalef(8, 0.5, 0.3);
                select_material(DEFAULT);
                draw_cube(1, true);
            }
            glPopMatrix();
        }

        // Top
        glBlendFunc(GL_ONE, GL_ZERO);
        glPushMatrix();
        {
            glTranslatef(0, 18.25, 0);
            glScalef(8, 0.5, 0.3);
            select_material(DEFAULT);
            draw_cube(1, true);
        }
        glPopMatrix();
        glDisable(GL_TEXTURE_2D);
        glBlendFunc(GL_ONE, GL_ZERO);
    }

    glPopMatrix();
}